<?php


define('DB_USER', "id5112410_scps");     // Your database user name
define('DB_PASSWORD', "sathysri98");			// Your database password (mention your db password here)
define('DB_DATABASE', "id5112410_scps"); // Your database name
define('DB_SERVER', "localhost");			// db server (Mostly will be 'local' host)

?>